﻿namespace FoodDeliveryManagement
{
    public class ServiceNowIncident
    {
        public string Number { get; set; }
        public string Short_description { get; set; }
    }
}
