using System;
using System.Windows.Forms;
using static System.Net.Mime.MediaTypeNames;

public class ListViewApp : Form
{
    private ListView listView;
    private TextBox inputBox;
    private Button addButton;
    private Button removeButton;

    public ListViewApp()
    {
        // Initialize the Form
        this.Text = "Win32 ListView Example";
        this.Width = 400;
        this.Height = 300;

        // Initialize the ListView control
        listView = new ListView();
        listView.Bounds = new System.Drawing.Rectangle(10, 10, 250, 200);
        listView.View = View.List; // Simple list view for displaying items
        listView.FullRowSelect = true;
        listView.MultiSelect = false; // Ensure single selection at a time

        // Initialize TextBox for user input
        inputBox = new TextBox();
        inputBox.Bounds = new System.Drawing.Rectangle(270, 10, 100, 20);

        // Initialize Add button
        addButton = new Button();
        addButton.Text = "Add Item";
        addButton.Bounds = new System.Drawing.Rectangle(270, 40, 100, 30);
        addButton.Click += new EventHandler(AddItem);

        // Initialize Remove button
        removeButton = new Button();
        removeButton.Text = "Remove Selected";
        removeButton.Bounds = new System.Drawing.Rectangle(270, 80, 100, 30);
        removeButton.Click += new EventHandler(RemoveSelectedItem);

        // Add controls to the form
        this.Controls.Add(listView);
        this.Controls.Add(inputBox);
        this.Controls.Add(addButton);
        this.Controls.Add(removeButton);
    }

    // Event handler to add an item to the ListView
    private void AddItem(object sender, EventArgs e)
    {
        if (!string.IsNullOrWhiteSpace(inputBox.Text))
        {
            listView.Items.Add(new ListViewItem(inputBox.Text));
            inputBox.Clear();
        }
        else
        {
            MessageBox.Show("Please enter a valid item name.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
    }

    // Event handler to remove the selected item from the ListView
    private void RemoveSelectedItem(object sender, EventArgs e)
    {
        if (listView.SelectedItems.Count > 0)
        {
            listView.Items.Remove(listView.SelectedItems[0]);
        }
        else
        {
            MessageBox.Show("Please select an item to remove.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
    }

    [STAThread]
    public static void Main()
    {
        Application.EnableVisualStyles();
        Application.Run(new ListViewApp());
    }
}
